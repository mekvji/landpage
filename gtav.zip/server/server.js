const express = require('express');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 8080;

// =============================================
// KONFIGURASI - EDIT SESUAI PC KAMU
// =============================================
const GAMES = {
  '1': { name: 'Minecraft',      cmd: 'start "" "C:\\Program Files (x86)\\Minecraft\\MinecraftLauncher.exe"' },
  '2': { name: 'GTA V',          cmd: 'start "" "D:\\Games\\GTAV\\PlayGTAV.exe"' },
  '3': { name: 'Among Us',       cmd: 'start "" "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Among Us\\Among Us.exe"' },
  '4': { name: 'Stardew Valley', cmd: 'start "" "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Stardew Valley\\Stardew Valley.exe"' },
  '5': { name: 'Hollow Knight',  cmd: 'start "" "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Hollow Knight\\hollow_knight.exe"' },
  '6': { name: 'Terraria',       cmd: 'start "" "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Terraria\\Terraria.exe"' },
  '7': { name: 'Celeste',        cmd: 'start "" "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Celeste\\Celeste.exe"' },
  '8': { name: 'Cuphead',        cmd: 'start "" "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Cuphead\\Cuphead.exe"' },
};
// =============================================

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', '*');
  next();
});

// Test koneksi dari HP
app.get('/ping', (req, res) => {
  res.json({ status: 'ok', message: 'CloudGame server aktif', time: Date.now() });
});

// List game (sama dengan cloudgame.json tapi bisa dari server langsung)
app.get('/games', (req, res) => {
  const jsonPath = path.join(__dirname, 'cloudgame.json');
  if (fs.existsSync(jsonPath)) {
    res.sendFile(jsonPath);
  } else {
    res.json(Object.entries(GAMES).map(([id, g]) => ({ id, title: g.name })));
  }
});

// Launch game di PC
app.get('/launch', (req, res) => {
  const gameId = req.query.game;
  const game = GAMES[gameId];

  if (!game) {
    return res.status(404).json({ error: 'Game tidak ditemukan', id: gameId });
  }

  console.log(`[LAUNCH] ${game.name}`);
  exec(game.cmd, (err) => {
    if (err) {
      console.error('[ERROR]', err.message);
      return res.status(500).json({ error: err.message });
    }
  });

  res.json({ status: 'launched', game: game.name });
});

// Stream endpoint - redirect ke halaman stream sederhana
app.get('/stream', (req, res) => {
  const gameId = req.query.game || '1';
  const game = GAMES[gameId] || { name: 'Game' };

  // Halaman HTML sederhana yang tampil di WebView HP
  res.send(`<!DOCTYPE html>
<html style="margin:0;background:#0A0C12;color:#fff;font-family:sans-serif;">
<body style="margin:0;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;">
  <div style="text-align:center;padding:20px;">
    <div style="font-size:48px;margin-bottom:16px;">⚡</div>
    <div style="color:#00D4FF;font-size:24px;font-weight:900;letter-spacing:4px;margin-bottom:8px;">CLOUDGAME</div>
    <div style="color:#fff;font-size:18px;margin-bottom:4px;">${game.name}</div>
    <div style="color:#8899BB;font-size:13px;margin-bottom:32px;">Streaming aktif dari PC kamu</div>
    <div style="color:#00FF88;font-size:12px;background:#0D2A1A;border:1px solid #00FF8833;padding:10px 20px;border-radius:8px;">
      ✓ Koneksi berhasil — game sedang berjalan di PC
    </div>
    <div style="margin-top:32px;color:#445577;font-size:11px;">
      Untuk streaming video penuh, integrasikan dengan<br>Sunshine/Moonlight atau OBS Virtual Camera
    </div>
  </div>
</body>
</html>`);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('  ⚡ CloudGame Server berjalan');
  console.log(`  http://localhost:${PORT}`);
  console.log('');
  console.log('  Endpoint aktif:');
  console.log(`  GET /ping       → test koneksi`);
  console.log(`  GET /launch?game=ID → launch game`);
  console.log(`  GET /stream?game=ID → stream page`);
  console.log('');
});
