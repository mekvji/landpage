@echo off
echo ================================
echo   CloudGame Server
echo ================================
echo.

where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js belum terinstall!
    echo Download di: https://nodejs.org
    pause
    exit
)

if not exist node_modules (
    echo Installing dependencies...
    npm install
    echo.
)

echo Starting server di port 8080...
echo Buka HP kamu dan hubungkan ke IP laptop ini.
echo.
node server.js
pause
